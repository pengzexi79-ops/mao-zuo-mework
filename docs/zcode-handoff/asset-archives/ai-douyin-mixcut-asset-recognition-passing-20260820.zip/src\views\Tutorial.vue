<template>
  <div>
    <div class="card">
      <div class="card-title">
        猫作 · Mework 内制教程
        <el-tag type="success" size="small">本机工作流</el-tag>
        <span class="spacer" style="flex:1"></span>
        <el-button size="small" @click="$router.push('/dashboard')">回到概览</el-button>
      </div>
      <el-alert
        title="按这条路径走，先干跑预览，再批量出片"
        description="教程里的按钮会直接打开对应页面；素材、项目和任务都留在本机。看不懂术语时，先展开下方‘白话解释’，按检查结果逐项处理。"
        type="info"
        show-icon
        :closable="false"
      />
      <el-alert v-if="selfCheck.length" type="warning" :closable="false" show-icon title="当前步骤自检">
        <ul style="margin:0;padding-left:20px"><li v-for="item in selfCheck" :key="item">{{ item }}</li></ul>
      </el-alert>
      <el-steps :active="0" simple class="workflow-steps">
        <el-step title="准备环境" />
        <el-step title="整理素材" />
        <el-step title="配置内容" />
        <el-step title="预览出片" />
        <el-step title="检查结果" />
      </el-steps>
    </div>

    <div class="grid c2" style="margin-top:14px">
      <div class="card">
        <div class="card-title">1. 准备环境 <span class="hint">先确认基础能力</span></div>
        <ol style="margin:0;padding-left:20px;line-height:2">
          <li>Windows 安装包已预置 Java、MySQL、FFmpeg、Python 媒体运行时和基础抓取工具，无需额外配置 PATH。</li>
          <li>从桌面或开始菜单启动 Mework，顶部状态应显示“后端：已连接”。若首次检测失败，请运行开始菜单中的“检查运行环境”。</li>
          <li>在“能力中心”查看每项能力的真实状态：已安装可用、修复安装、官方安装说明或账号授权。</li>
          <li>模型文件、硬件驱动、第三方 API Key 和登录授权必须按官方条件单独完成；它们不会影响使用已有本地素材出片。</li>
          <li>macOS/Linux 需要另行准备 Java、MySQL、FFmpeg 与 Python 运行时；当前安装器交付目标为 Windows x64。</li>
        </ol>
        <div class="form-hint">不要把数据库密码、访问令牌或第三方 API Key 写进页面或提交到代码库。</div>
        <div style="margin-top:12px">
          <el-button type="primary" @click="$router.push('/ai')">配置 AI</el-button>
          <el-button @click="$router.push('/studio')">查看运行状态</el-button>
          <el-button size="small" @click="markDone('env')">我已检查环境</el-button>
        </div>
      </div>

      <div class="card">
        <div class="card-title">2. 整理素材 <span class="hint">先归档，再授权</span></div>
        <ol style="margin:0;padding-left:20px;line-height:2">
          <li>在“素材库”填写本机目录并递归扫描，或上传已授权文件。</li>
          <li>按文件名自动打标后，检查 hook、body、product、celebrity、endcard、voice、bgm。</li>
          <li>用文件夹管理品牌、产品线或项目边界；素材可移动到指定文件夹。</li>
          <li>至少准备一段自家产品素材和一条 BGM，成片才不会缺核心内容。</li>
        </ol>
        <div style="margin-top:12px">
          <el-button type="primary" @click="$router.push('/materials')">打开素材库</el-button>
          <el-button @click="$router.push('/crawl')">了解公开抓取</el-button>
          <el-button size="small" @click="markDone('materials')">我已导入素材</el-button>
        </div>
      </div>
    </div>

    <div class="card" style="margin-top:14px">
      <div class="card-title">3. 配置内容和工作流 <span class="hint">让每条片子有明确目标</span></div>
      <div class="grid c3">
        <div>
          <el-tag type="warning" effect="plain">项目</el-tag>
          <p class="form-hint">填写品牌、产品、卖点和受众。项目是 AI 文案与出片参数的业务上下文。</p>
          <el-button size="small" @click="$router.push('/projects')">管理项目</el-button>
        </div>
        <div>
          <el-tag type="success" effect="plain">工作流</el-tag>
          <p class="form-hint">优先使用中文向导，依次设置素材范围、时长、结构、画幅和音频。</p>
          <el-button size="small" @click="$router.push('/workflows')">编辑工作流</el-button>
        </div>
        <div>
          <el-tag type="info" effect="plain">授权范围</el-tag>
          <p class="form-hint">在出片控制台选择文件夹后，只使用授权范围内的素材；不选则使用全部已归档素材。</p>
          <el-button size="small" @click="$router.push('/studio')">设置授权文件夹</el-button>
        </div>
      </div>
    </div>

    <div class="card" style="margin-top:14px">
      <div class="card-title">4. 先干跑，再批量渲染 <span class="hint">先看时间线，再消耗渲染资源</span></div>
      <el-steps :active="1" finish-status="success" align-center>
        <el-step title="选项目和工作流" description="确认素材范围与参数" />
        <el-step title="预览第 N 条" description="不渲染，只生成时间线" />
        <el-step title="确认产品段" description="检查时长和音频" />
        <el-step title="开始出片" description="按队列批量渲染" />
      </el-steps>
      <div style="margin-top:16px;text-align:center">
        <el-button type="primary" @click="$router.push('/studio')">打开出片控制台</el-button>
        <el-button type="success" @click="$router.push('/outputs')">查看成片库</el-button>
      </div>
    </div>

    <div class="card" style="margin-top:14px">
      <div class="card-title">参数与术语说明 <span class="hint">复杂设置放在教程里，不干扰日常操作</span></div>
      <el-collapse>
        <el-collapse-item title="时长区间、切片与帧率" name="timing">
          <p class="form-hint">时长区间是成片允许的最短和最长秒数；总时长优先时会在区间内收敛。切片是从长素材取出的单段画面，切片随机变化可避免每段都完全等长。帧率决定每秒画面数量，常用 24/25/30，60fps 适合高运动内容但渲染成本更高。</p>
        </el-collapse-item>
          <el-collapse-item title="响度、BGM 轮换与字幕" name="audio">
          <p class="form-hint">静音模式会移除最终音频流，并同时关闭新字幕和原片字幕安全区处理。保留原声会继续使用原片音频；背景音乐模式会按项目历史和本批已用次数优先轮换不同的可读 BGM/口播，只有素材池只有一条时才会循环并在任务说明中提示。关闭字幕只会关闭新烧录字幕，不会自动清除原片画面里已经存在的字幕；需要遮挡原片字幕时请单独打开“原片字幕处理”。</p>
        </el-collapse-item>
        <el-collapse-item title="公开链接、来源校验与精选检索" name="exchange">
          <p class="form-hint">抓取页只把真正接入的来源显示为可检索；未接入的网站只提供官方页，不会把网页或搜索页当成媒体直链。视频和音频精选区提供受控关键词检索方案，搜索结果仍需通过 http/https、来源许可、链接可达性和媒体质量检查。工作流/Skill 可导入导出版本化 JSON 包；导入的 Skill 仍受 DSL 白名单约束，不会执行命令、网络请求或任意文件操作。</p>
        </el-collapse-item>
      </el-collapse>
    </div>

    <div class="card" style="margin-top:14px">
      <div class="card-title">5. 任务观察与恢复 <span class="hint">遇到失败先看原因</span></div>
      <el-collapse>
        <el-collapse-item title="怎么看任务进度" name="progress">
          <p class="form-hint">任务列表会显示等待、运行、完成、失败或取消状态；运行中的阶段和百分比用于判断当前是否仍在推进。</p>
          <p class="form-hint">队列指标包括渲染中、等待数量、线程池和队列长度。高分辨率任务建议从低并发开始。</p>
        </el-collapse-item>
        <el-collapse-item title="失败后怎么处理" name="failure">
          <p class="form-hint">先打开任务详情，确认失败原因和输出文件，再使用重试入口提交未完成项。不要手工删除检查点。</p>
          <p class="form-hint">取消任务会保留已完成输出；本机重启或外部 ffmpeg 失败时，重新提交未完成任务即可。</p>
        </el-collapse-item>
        <el-collapse-item title="高级 DSL 能做什么" name="dsl">
          <p class="form-hint">自定义技能只允许操作素材池、参数、文案和音量。命令、shell、URL、HTTP、下载、模板、文件路径和未知字段都会被拒绝。</p>
          <pre class="mono" style="white-space:pre-wrap;background:#f7f8fa;padding:10px;border-radius:4px">{"version":1,"steps":[{"op":"select_materials","roles":["body","product"]},{"op":"set_params","params":{"minSec":50,"maxSec":90}}]}</pre>
        </el-collapse-item>
      </el-collapse>
    </div>

    <div class="card" style="margin-top:14px">
      <div class="card-title">白话解释：每个词到底是什么意思</div>
      <el-collapse>
        <el-collapse-item title="为什么导入后还显示处理中？" name="import-state"><p class="form-hint">文件已经安全保存，但系统还在用 ffprobe 读取时长、分辨率并生成缩略图。这个阶段不是丢失。请等状态变为可用；如果失败，打开错误详情并点击重试。</p></el-collapse-item>
        <el-collapse-item title="人文关键词为什么会找到纪录片风格音乐？" name="audio-intent"><p class="form-hint">系统会把“人文”转换为 documentary、world、ambient、cinematic 等公开音乐标签，再按许可证和命中度排序。没有命中时会明确告诉你，不会偷偷换成随机音乐。</p></el-collapse-item>
        <el-collapse-item title="什么叫干跑、切片、编辑候选？" name="render-terms"><p class="form-hint">干跑只生成时间线清单，不编码视频；切片是从长视频取出的短段；候选编辑会先保存独立草稿，再渲染并通过质检，只有明确点击应用才会替换当前成片。编辑台的可视化时间线可以点击单段进入修剪，但它不是完整多轨剪映替代。</p></el-collapse-item>
        <el-collapse-item title="出片前处理、成片编辑与 AI 创作" name="media-tools"><p class="form-hint">出片控制台顶部先选择项目、固定顺序或素材范围，再通过“AI 创作”“固定顺序”和“素材库”入口开始工作。固定顺序导入后会完整显示每一步，缺素材时可回素材库或素材抓取补齐，不会跨步骤取材。成片生成后从成片库进入编辑器，候选必须通过质检才可应用。AI 创作可提交已确认的图片、视频和配音生成，完成后自动入素材库。</p></el-collapse-item>
        <el-collapse-item title="AI 助手拖动和游戏中心" name="assistant-games"><p class="form-hint">点击助手图标打开对话；大距离拖动助手并松手会打开离线游戏中心。普通点击、轻微移动和素材文件拖放不会触发游戏，也不会再显示全屏巨大投放提示。助手会在你停留在对话底部时自动跟随最新文本，上滑阅读历史时不会强行跳回底部。</p></el-collapse-item>
        <el-collapse-item title="资源中心、模型和官方充值" name="resources"><p class="form-hint">资源中心的每张卡都会标明是官方入口、免登录查看、需要账号还是可能计费。能直接进入应用的资源会跳到素材抓取、AI 接入或工作流页面；纯参考资料只打开官方页面，不做代理下载。能力中心中的“随包可用、可修复安装、需配置、需官方/硬件”含义不同，看到“检测到”不等于已经接入出片链路。</p></el-collapse-item>
        <el-collapse-item title="处理结果与保存位置" name="media-visual"><p class="form-hint">出片前处理和成片编辑生成的结果都会作为新素材或候选版本保存，原文件默认保留。通过保存位置只修改之后生成的图片、视频片段和音频处理目录；应用会拒绝系统目录、项目目录和磁盘根目录，旧文件不会被移动或覆盖。</p></el-collapse-item>
        <el-collapse-item title="付费 AI 生成与模型接入" name="paid-ai"><p class="form-hint">在“AI 接入”新增供应商后填写官方或第三方兼容地址和 API Key，点击“识别模型”。识别结果只是候选：文本模型可用于脚本、钩子和规划；图片、视频、配音必须由你明确采用并保存到执行能力列表。AI 创作只显示真实可执行模型；没有能力时会告诉你缺少什么接口和配置路径。提交生成前仍会要求确认额度，结果完成后自动入素材库。应用不代收款、不保存浏览器登录态，也不绕过地区、登录、付费、DRM 或内容审核限制。</p></el-collapse-item>
        <el-collapse-item title="哪些素材可以抓？" name="license"><p class="form-hint">素材抓取按三类显示：免 Key 可直接检索、配置官方 Key 后可检索、官方处理或登录后自行下载再导入。免登录不等于免版权，商用前要保存许可证或授权记录。系统只接受 http/https，并会拒绝 localhost、内网、环回、保留地址、登录态、DRM 或无授权链接；不会读取 Cookie 或密码。</p></el-collapse-item>
      </el-collapse>
    </div>

    <div class="card" style="margin-top:14px">
      <div class="card-title">常见问题</div>
      <el-alert title="后端不可达 / 数据库未连接" type="warning" show-icon :closable="false" style="margin-bottom:10px">
        检查 MySQL、DB_URL、DB_USERNAME、DB_PASSWORD 和 8760 端口；修复后点击顶部“刷新状态”。
      </el-alert>
      <el-alert title="未检测到 ffmpeg" type="warning" show-icon :closable="false" style="margin-bottom:10px">
        将 ffmpeg / ffprobe 加入 PATH，或在本机配置 APP_FFMPEG、APP_FFPROBE，然后重启后端。
      </el-alert>
      <el-alert title="抓取失败" type="info" show-icon :closable="false">
        只提交公开、免登录的 http/https 链接。系统会拦截 localhost、私网、保留地址和不安全重定向，也不会读取 Cookie。
      </el-alert>
    </div>
  </div>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import { api } from '../api'

const env = ref({})
const done = ref(JSON.parse(localStorage.getItem('mework-tutorial-done') || '{}'))
const selfCheck = computed(() => {
  const items = []
  if (env.value.databaseConnected === false) items.push('数据库还没有连接：检查 DB_URL、DB_USERNAME、DB_PASSWORD 后重启后端。')
  if (env.value.ffmpeg === false) items.push('没有检测到 ffmpeg/ffprobe：安装后加入 PATH，再点击顶部刷新状态。')
  if (!done.value.env) items.push('完成“准备环境”后点击“我已检查环境”。')
  if (!done.value.materials) items.push('至少导入一段视频和一条 BGM，才能验证完整出片。')
  return items
})
function markDone (key) {
  done.value = { ...done.value, [key]: true }
  localStorage.setItem('mework-tutorial-done', JSON.stringify(done.value))
}
onMounted(async () => { try { env.value = await api.env() } catch {} })
</script>
